Projeto sistema jogo de xadrez sem interface gráfica.
