package javabasics;
public class ExpressoesComparativa {
    /*
    a += b; é, a = a + b;
    a -= b; é, a = a - b;
    a *= b; é, a = a * b;
    a /= b; é, a = a / b;
    a %= b; é, a = a % b;


    > maior que
    < menor que
    >= maior ou igual que
    <= menor ou igual que 
    == igual 
    != diferente
    */

        /* 
        Operadores Lógicos
        && = E (A expressão inteira deve ser V)
        ! = Não (Inverte a expressão lógica)
        || = OU (Ao menos 1 condição tem que ser V)

        int x = 5;
        x <= 20 && x == 10; Falso
        x > 0 && x != 3; Verdadeiro

        x => 10 || x <= 20; Verdadeiro
        x > 0 || x != 3; Verdadeiro
        
        !(x == 10); (ou seja x não é igual a 10) Verdadeiro
        !(x >= 2 && x == 10); Verdadeiro 
        */
    

}
