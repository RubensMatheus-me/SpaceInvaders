package entities;

public class ProductPolimorfism {

    private String name;
    private Double price;
    
    public ProductPolimorfism() {
    }

    public ProductPolimorfism(String name, Double price) {
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public Double getPrice() {
        return price;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String priceTag() {
        return name + " $ " + String.format("%.2f", price);
    }
}
