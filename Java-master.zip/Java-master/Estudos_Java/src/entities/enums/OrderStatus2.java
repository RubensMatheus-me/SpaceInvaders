package entities.enums;

public enum OrderStatus2 {
    
    PENDING_PAYMENT,
    PROCESSING,
    SHIPPED,
    DELIVERED;
}
