package entities;

public class PostComments {
    
    private String text;

    public PostComments() {
    }

    public PostComments(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}

