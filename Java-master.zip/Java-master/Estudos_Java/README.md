A pasta 'src' irá conter os arquivos principais da programação java.
A pasta 'bin' irá conter apenas as classes criadas.


