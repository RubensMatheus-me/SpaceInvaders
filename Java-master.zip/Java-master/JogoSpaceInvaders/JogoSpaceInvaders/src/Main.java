import game.Game;

//Integer.parseInt("string");
public class Main {
    public static void main (String[] args) {
        new Game();

    }
}
